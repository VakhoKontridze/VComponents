//
//  VComponents.h
//  VComponents
//
//  Created by Vakhtang Kontridze on 19.12.20.
//

#import <Foundation/Foundation.h>

//! Project version number for VComponents.
FOUNDATION_EXPORT double VComponentsVersionNumber;

//! Project version string for VComponents.
FOUNDATION_EXPORT const unsigned char VComponentsVersionString[];
